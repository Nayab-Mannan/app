import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule,FormGroup,FormControl,FormBuilder } from '@angular/forms';
import { ViewChild } from '@angular/core';
import { NgxCsvParser } from 'ngx-csv-parser';
import { NgxCSVParserError } from 'ngx-csv-parser';
import { ngxCsv } from 'ngx-csv/ngx-csv';



@Component({
  selector: 'app-informatics',
  templateUrl: './informatics.component.html',
  styleUrls: ['./informatics.component.css']
})
export class InformaticsComponent{
  isShown: boolean = false ; // hidden by default 
  csvRecords: any[] = [];
  header = false;
  btnName={}
  // PAGINATION
  p: number = 1;
  collection: any[] = []; 
  pageSize=15; 

  constructor(private ngxCsvParser: NgxCsvParser,private http:HttpClient) {
  }

  @ViewChild('fileImportInput', { static: false }) fileImportInput: any;

  // Your applications input change listener for the CSV File
  fileChangeListener($event: any): void {

    // Select the files from the event
    const files = $event.srcElement.files;
    console.log($event.target.files[0].name);
  
    
    // Parse the file you want to select for the operation along with the configuration
    this.ngxCsvParser.parse(files[0], { header: this.header, delimiter: ',' })
      .pipe().subscribe((result:any) => {
        console.log('Result', result);
        this.csvRecords = result;
      }, (error: NgxCSVParserError) => {
        console.log('Error', error);
      });
      // alert('Uploaded Successfully.');

  }

toggleShow() {
  this.isShown = true;
 
  
  }
  downloadCSV(){
    var options = { 
      fieldSeparator: ',',
      quoteStrings: '"',
      decimalseparator: '.',
      showLabels: true, 
      showTitle: true,
      title: 'Your title',
      useBom: true,
      headers: ["CRIM","ZN","INDUS","CHAS","NOX","RM","AGE","DIS","RAD","TAX","PTRATIO","B"]
    };
   
    new ngxCsv( this.csvRecords, "informatics", options);
  }
  getValue(event: Event): string {
    return (event.target as HTMLInputElement).value;

  }

  
 }

 




